//
//  ViewController.swift
//  expandableTableViewTasKAPP
//
//  Created by iMac on 16/09/22.
//

import UIKit
import Kingfisher

// GlobalVariable Declare
var tblModel: companyData?

class expandableViewController: UIViewController {

    //MARK: OutLet
    @IBOutlet weak var multipleCellTabelView: UITableView!
    var companyDetails:[companyHeaders]?
    
    //MARK: - View Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.title = "Offering"
        setNavigationBar()
        multipleCellTabelView.delegate = self
        multipleCellTabelView.dataSource = self
        registerCell()
        companyDetailsSet()
        fetchData { model in
            tblModel = model
            DispatchQueue.main.async {
                self.multipleCellTabelView.reloadData()
            }
        }
    }
    
    //MARK: - Set multiple section
    func companyDetailsSet(){
        companyDetails = [                                                       // Sections
            companyHeaders(header: "CompanyInfo", rowData: 0),                       // 0
            companyHeaders(header: "Purpose Of The Offering", rowData: 1),           // 1
            companyHeaders(header: "Product And Service", rowData: 1),               // 2
            companyHeaders(header: "Officers Of The Company", rowData: 3),           // 3
            companyHeaders(header: "Offering Information", rowData: 12),             // 4
            companyHeaders(header: "Investor Perks", rowData: 1),                    // 5
            companyHeaders(header: "Business Plan", rowData: 1),                     // 6
            companyHeaders(header: "Risk Factor", rowData: 1),                       // 7
            companyHeaders(header: "Use Of Fund", rowData: 1),                       // 8
            companyHeaders(header: "Other Information", rowData: 1),                 // 9
            companyHeaders(header: "Offering Document", rowData: 2),                 // 10
            companyHeaders(header: "Data Room", rowData: 2),                         // 11
            companyHeaders(header: "Updates", rowData: 1),                           // 12
            companyHeaders(header: "Comment", rowData: 1)                            // 13
        ]
    }
    
    //MARK: -  Fetch Data From API Using URLSession
    func fetchData(compeleted: @escaping (_ comp: companyData)->()){
        let url = URL(string: "https://cms.akemona-dev2.com/offerings/61208afbdbed500ecf4dd9aa")
        
        URLSession.shared.dataTask(with: url!) { serverData, response, Error in
            if Error != nil{
                print(Error?.localizedDescription ?? "")
            }else{
                
                if let data = serverData{
                    do{
                        let compData = try JSONDecoder().decode(companyData.self, from: data)
                        debugPrint(compData)
                        compeleted(compData)
                        
                    }catch let error {
                        print(error.localizedDescription)
                        print("Fetching Error from API")
                    }
                }else{
                    print("Data is NOt Yet")
                }  
            }
        }.resume()
    }
}

//MARK: - TableView Delegate &  DataSource Method
extension expandableViewController: UITableViewDelegate, UITableViewDataSource{
    
    // MARK: Cell Register
    private func registerCell(){
        
        multipleCellTabelView.register(UINib(nibName: "headerCell", bundle: nil), forCellReuseIdentifier: "headerCell")
        multipleCellTabelView.register(UINib(nibName: "companyInformationCell", bundle: nil), forCellReuseIdentifier: "companyInformationCell")
        multipleCellTabelView.register(UINib(nibName: "singleLabelCell", bundle: nil), forCellReuseIdentifier: "singleLabelCell")
        multipleCellTabelView.register(UINib(nibName: "imageCell", bundle: nil), forCellReuseIdentifier: "imageCell")
        multipleCellTabelView.register(UINib(nibName: "offeringInformationCell", bundle: nil), forCellReuseIdentifier: "offeringInformationCell")
        multipleCellTabelView.register(UINib(nibName: "documentCell", bundle: nil), forCellReuseIdentifier: "documentCell")
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return companyDetails?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let section1 = companyDetails![section]
        if section1.isOpened {
            return section1.rowData + 1
        }else{
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 && indexPath.row == 0{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "companyInformationCell", for: indexPath) as? companyInformationCell else{ return .init()}
            cell.setCompanyMainHeading()
            return cell
        }else if indexPath.section > 0 && indexPath.row == 0{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "headerCell", for: indexPath) as? headerCell else{ return .init()}
            
            let section = companyDetails?[indexPath.section]
            cell.labelHeader.text = section?.header
            if section?.isOpened == true{
                cell.sectionOpen()
            }else{
                cell.sectionClosed()
            }
            return cell
            
        }else if indexPath.section == 1 && indexPath.row > 0 {
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "singleLabelCell", for: indexPath) as? singleLabelCell else{ return .init()}
            if let offeringPurpose = tblModel?.data?.value?.memo?.offeringPurpose{
                cell.singleLabelText.setHTMLFromString(htmlText: offeringPurpose)
            }
            return cell
            
        }else if indexPath.section == 2 && indexPath.row > 0{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "singleLabelCell", for: indexPath) as? singleLabelCell else{ return .init()}
            if let productServices = tblModel?.data?.value?.memo?.productsServices{
                cell.singleLabelText.setHTMLFromString(htmlText: productServices)
            }
            return cell
            
        }else if indexPath.section == 3 && indexPath.row > 0{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "imageCell", for: indexPath) as? imageCell else{ return .init()}
            cell.setValue()
            cell.officerName.text = cell.holderDetailsArray![indexPath.row - 1].attachment?.name?.capitalized.replacingOccurrences(of: ".Jpg", with: "").replacingOccurrences(of: ".Pdf", with: "")
            
            cell.officerImage.setImage(with: cell.holderDetailsArray![indexPath.row - 1].attachment?.url ?? "https://archive.ebrschools.org/wp-content/themes/ebr/img/nofound.png")
            cell.officerPost.text = cell.holderDetailsArray![indexPath.row - 1].attachment?.provider?.capitalized
            

            return cell
            
        }else if indexPath.section == 4 && indexPath.row > 0{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "offeringInformationCell", for: indexPath) as? offeringInformationCell else{ return .init()}
            cell.setCellValue()
            cell.labelName1.text = cell.offeringInformationArray![indexPath.row - 1].key
            cell.labelName2.text = cell.offeringInformationArray![indexPath.row - 1].value1
            cell.labelName3.text = cell.offeringInformationArray![indexPath.row - 1].value2.replacingOccurrences(of: cell.offeringInformationArray![indexPath.row - 1].value2.dropFirst(8).dropLast(8), with: "...")
            
            cell.delegate = self
            cell.setCellView()
            return cell
            
        }else if indexPath.section == 5 && indexPath.row > 0{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "singleLabelCell", for: indexPath) as? singleLabelCell else{ return .init()}
                cell.singleLabelText.text = tblModel?.data?.value?.memo?.investorPerks
            return cell
            
        }else if indexPath.section == 6 && indexPath.row > 0{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "singleLabelCell", for: indexPath) as? singleLabelCell else{ return .init()}
            if let businessPlan = tblModel?.data?.value?.memo?.businessPlan{
                cell.singleLabelText.setHTMLFromString(htmlText: businessPlan)
            }
            return cell
            
        }else if indexPath.section == 7 && indexPath.row > 0{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "singleLabelCell", for: indexPath) as? singleLabelCell else{ return .init()}
            if let riskFactors = tblModel?.data?.value?.memo?.riskFactors{
                cell.singleLabelText.setHTMLFromString(htmlText: riskFactors)
            }
            return cell
            
        }else if indexPath.section == 8 && indexPath.row > 0{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "singleLabelCell", for: indexPath) as? singleLabelCell else{ return .init()}
            if let useOfFundsDescription = tblModel?.data?.value?.memo?.useOfFundsDescription{
                cell.singleLabelText.setHTMLFromString(htmlText: useOfFundsDescription)
            }
            return cell
            
        }else if indexPath.section == 9 && indexPath.row > 0{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "singleLabelCell", for: indexPath) as? singleLabelCell else{ return .init()}
            if let otherMaterial = tblModel?.data?.value?.memo?.otherMaterial{
                cell.singleLabelText.setHTMLFromString(htmlText: otherMaterial)
            }
            return cell
            
        }else if indexPath.section == 10 && indexPath.row > 0{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "documentCell", for: indexPath) as? documentCell else{ return .init()}
            if indexPath.row == 1{
                cell.labelDocumentName.text = "Offering Memorandium"
            }else{
                cell.labelDocumentName.text = "Debt Aggrement"
            }
            return cell
            
        }else if indexPath.section == 11 && indexPath.row > 0{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "documentCell", for: indexPath) as? documentCell else{ return .init()}
            if indexPath.row == 1{
                cell.labelDocumentName.text = "Test 1.Pdf"
            }else{
                cell.labelDocumentName.text = "Test 2.pdf"
            }
            return cell
            
        }else if indexPath.section == 12 && indexPath.row > 0{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "singleLabelCell", for: indexPath) as? singleLabelCell else{ return .init()}
            cell.singleLabelText.text = "No Any Data"
            return cell
            
        }else if indexPath.section == 13 && indexPath.row > 0{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "singleLabelCell", for: indexPath) as? singleLabelCell else{ return .init()}
            cell.singleLabelText.text = "No Any Data"
            return cell
            
        }else{
            guard let cell = multipleCellTabelView.dequeueReusableCell(withIdentifier: "singleLabelCell", for: indexPath) as? singleLabelCell else{ return .init()}
            cell.singleLabelText.text = "No Any Data"
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section > 0 && indexPath.row == 0{
            let section = companyDetails![indexPath.section]
            section.isOpened = !section.isOpened
            multipleCellTabelView.reloadSections([indexPath.section], with: .none)
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        UITableView.automaticDimension
    }
}

//MARK: - Implement Delegate Method & Copy using Butten tapped
extension expandableViewController: MyCellDelegate{
    
    //6. Implement Delegate Method
    func btnCopyTapped(cell: offeringInformationCell, offeringInformationArray: [offeringData]) {
        let indexPath = self.multipleCellTabelView.indexPath(for: cell)
        print(indexPath!.row)
        print(offeringInformationArray[indexPath!.row - 1].value2)
        UIPasteboard.general.string = offeringInformationArray[indexPath!.row - 1].value2
    }
        
}

//MARK: -  Extension For Set Navigation Item
extension expandableViewController{
    func setNavigationBar() {
        self.navigationController?.navigationBar.isHidden = false
        navigationController?.setNavigationBarHidden(false, animated: false)
        
        let buttonHome = UIButton(type: .custom)
        buttonHome.setImage(UIImage(named: "home1"), for: .normal)
        buttonHome.frame = CGRect(x: 0, y: 4, width: 25, height: 25)
        buttonHome.showsTouchWhenHighlighted = false
        buttonHome.isUserInteractionEnabled = false
        let rightBarButtonItems = UIView(frame: CGRect(x: 0, y: 0, width: 36, height: 36))
        rightBarButtonItems.addSubview(buttonHome)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: rightBarButtonItems)
    }
}

//MARK: - Html string to convert plain text
extension UILabel {
    func setHTMLFromString(htmlText: String) {
        let modifiedFont = String(format:"<span style=\"font-family: '-apple-system', 'HelveticaNeue'; font-size: \(self.font!.pointSize)\">%@</span>", htmlText)

        let attrStr = try! NSAttributedString(
            data: modifiedFont.data(using: .unicode, allowLossyConversion: true)!,
            options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding:String.Encoding.utf8.rawValue],
            documentAttributes: nil)

        self.attributedText = attrStr.trimmedAttributedString()
    }
    
    
}

extension expandableViewController{
    
}

//MARK: - Remove White Space In NSAttributed String
extension NSAttributedString {
    func trimmedAttributedString() -> NSAttributedString {
        let nonNewlines = CharacterSet.whitespacesAndNewlines.inverted
        // 1
        let startRange = string.rangeOfCharacter(from: nonNewlines)
        // 2
        let endRange = string.rangeOfCharacter(from: nonNewlines, options: .backwards)
        guard let startLocation = startRange?.lowerBound, let endLocation = endRange?.lowerBound else {
            return self
        }
        // 3
        let range = NSRange(startLocation...endLocation, in: string)
        return attributedSubstring(from: range)
    }
    
    
}

//MARK: - Trancate Middle In String
extension String {
    func replacingRange(indexFromStart: Int, indexFromEnd: Int, replacing: String = "") -> Self {
        return self.replacingOccurrences(of: self.dropFirst(indexFromStart).dropLast(indexFromEnd), with: replacing)
    }
    
    func replacingRange2(indexFromStart: Int, indexFromEnd: Int, replacing: String = "") -> Self {
        return String(self.prefix(indexFromStart)) + replacing + String(self.suffix(indexFromEnd))
    }
    
    func removeSpecialCharsFromString(text: String) -> String {
        let okayChars = Set("abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLKMNOPQRSTUVWXYZ1234567890+-=().!_")
        return text.filter {okayChars.contains($0) }
    }

}

//MARK: - Image Load Using KingFisher
extension UIImageView {
    func setImage(with urlString: String){
        
        let imageURL = "https://cms.akemona-dev2.com\(urlString)"
        guard let url = URL.init(string: imageURL) else {
            return
        }
        let resource = ImageResource(downloadURL: url, cacheKey: imageURL)
        var kf = self.kf
        kf.indicatorType = .activity
        self.kf.setImage(with: resource)
    }
}
