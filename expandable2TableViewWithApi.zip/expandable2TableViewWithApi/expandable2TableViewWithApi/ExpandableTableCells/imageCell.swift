//
//  imageCell.swift
//  expandableTableViewTasKAPP
//
//  Created by iMac on 16/09/22.
//

import UIKit

class imageCell: UITableViewCell {

    //MARK : Outlet declare
    @IBOutlet weak var officerName: UILabel!
    @IBOutlet weak var officerImage: UIImageView!
    @IBOutlet weak var officerPost: UILabel!
    
    @IBOutlet weak var backView: UIView!
    
    var holderDetailsArray:[Edgarfilingdocument]?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        backviewBorderSet()
        SetRoundImage()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
 
    func setValue(){
        holderDetailsArray = tblModel?.edgarfilingdocuments
    }
    
    func SetRoundImage(){
        officerImage.layer.cornerRadius = officerImage.frame.height/2
    }
    
    func backviewBorderSet(){
        
//        self.backView.layer.borderWidth = 0.7
//        self.backView.layer.borderColor = UIColor.init(cgColor: CGColor(red: 0.0/255.0, green: 0.0/255.0, blue: 0.0/255.0, alpha: 0.6)).cgColor
        self.backView.layer.cornerRadius = 8
        self.backView.layer.layoutIfNeeded()
    }
}
