//
//  headerCell.swift
//  expandable2TableViewWithApi
//
//  Created by iMac on 21/09/22.
//

import UIKit

class headerCell: UITableViewCell {

    @IBOutlet weak var labelHeader: UILabel!
    @IBOutlet weak var headerView: UIView!
    @IBOutlet weak var headerImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func sectionOpen(){
        headerImage.isHidden = false
        headerImage.image = UIImage(systemName: "chevron.down")
        headerImage.tintColor = .white
        headerView.backgroundColor = UIColor.init(cgColor: CGColor(red: 34.0/255.0, green: 128.0/255.0, blue: 98.0/255.0, alpha: 1.0))
        labelHeader.textColor = .white
    }
    
    func sectionClosed(){
        headerImage.isHidden = true
        headerView.backgroundColor = .systemBackground
        labelHeader.textColor = .black
        headerView.layer.borderColor = UIColor(red: 34.0/255.0, green: 128.0/255.0, blue: 98.0/255.0, alpha: 1).cgColor
        headerView.layer.borderWidth = 1
        headerView.layoutIfNeeded()
    }
}
