//
//  twoLabelCell.swift
//  expandableTableViewTasKAPP
//
//  Created by iMac on 16/09/22.
//

import UIKit

//MARK: - Declare protocol for Button Action
protocol MyCellDelegate: AnyObject {
    // pass cell & array of offering data
    func btnCopyTapped(cell: offeringInformationCell, offeringInformationArray:[offeringData])
    
}

class offeringInformationCell: UITableViewCell {

    //MARK : Outlet declare
    @IBOutlet weak var labelName1: UILabel!
    @IBOutlet weak var labelName2: UILabel!
    @IBOutlet weak var labelName3: UILabel!
    
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var lineView: UIView!
    @IBOutlet weak var label2View: UIView!
    @IBOutlet weak var label3view: UIView!
    
    @IBOutlet weak var buttonCopy: UIButton!
    
    var offerInformationData:AppendData?
    var offeringInformationArray:[offeringData]?
    
    //2. create delegate variable
    weak var delegate: MyCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        backviewBorderSet()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func buttonCopyAction(_ sender: Any) {
        //4. call delegate method
        delegate?.btnCopyTapped(cell: self, offeringInformationArray: offeringInformationArray!)
    }
    
    func setCellValue(){
        offerInformationData = AppendData.init(offeringData: tblModel?.data?.value?.formData?.offeringInformation)
        
        offeringInformationArray = [
            offeringData(key: "No Of Security Offered", value1: offerInformationData?.offeringData?.noOfSecurityOffered ?? "No Data Found", value2: ""),
            offeringData(key: "Deadline Date", value1: offerInformationData?.offeringData?.deadlineDate ?? "No Data Found", value2: ""),
            offeringData(key: "Security Offered Other Desction", value1: offerInformationData?.offeringData?.securityOfferedOtherDesc ?? "No Data Found", value2: ""),
            offeringData(key: "Price", value1: offerInformationData?.offeringData?.price ?? "No Data Found", value2: "025478767_x3geryeryerty45y5grty45645yfr56"),
            offeringData(key: "Compensation Amount", value1: offerInformationData?.offeringData?.compensationAmount ?? "No Data Found", value2: ""),
            offeringData(key: "Rolling Close", value1: offerInformationData?.offeringData?.rollingClose ?? "No Data Found", value2: ""),
            offeringData(key: "Security Offered Type", value1: offerInformationData?.offeringData?.securityOfferedType ?? "No Data Found", value2: ""),
            offeringData(key: "Financial Interest", value1: offerInformationData?.offeringData?.financialInterest ?? "No Data Found", value2: ""),
            offeringData(key: "Over Subscription Accepted", value1: offerInformationData?.offeringData?.overSubscriptionAccepted ?? "No Data Found", value2: ""),
            offeringData(key: "Price Determination Method", value1: offerInformationData?.offeringData?.priceDeterminationMethod ?? "No Data Found", value2: "255gfgdfgfdgfdgd645645gdft455645g645"),
            offeringData(key: "Maximum Offering Amount", value1: offerInformationData?.offeringData?.maximumOfferingAmount ?? "No Data Found", value2: "4557_0xs5ggfgtert45645g6455gdf2544j"),
            offeringData(key: "Offering Amount", value1: offerInformationData?.offeringData?.offeringAmount ?? "No Data Found", value2: "")
        ]
    }
    
    func setCellView(){
        if labelName2.text == "" || labelName2.text == nil{
            label2View.isHidden = true
            lineView.isHidden = true
        }else{
            
            label2View.isHidden = false
            lineView.isHidden = false
            
            if labelName2.text == tblModel?.data?.value?.formData?.offeringInformation?.deadlineDate{
                labelName2.textColor = UIColor(red: 34.0/255.0, green: 128.0/255.0, blue: 98.0/255.0, alpha: 1)
            }else{
                labelName2.textColor = .black
            }
        }
        
        if labelName3.text ==  nil || labelName3.text == ""{
            label3view.isHidden = true
        }else{
            label3view.isHidden = false
            lineView.isHidden = false
        }   
    }
    
    func backviewBorderSet(){
        
        self.backView.layer.borderWidth = 0.7
        self.backView.layer.borderColor = UIColor.init(cgColor: CGColor(red: 0.0/255.0, green: 0.0/255.0, blue: 0.0/255.0, alpha: 0.6)).cgColor
        self.backView.layer.cornerRadius = 8
        self.backView.layer.layoutIfNeeded()
    }
}
