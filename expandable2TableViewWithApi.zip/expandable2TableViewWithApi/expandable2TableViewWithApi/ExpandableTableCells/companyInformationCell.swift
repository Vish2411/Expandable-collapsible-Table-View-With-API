//
//  HeaderCell.swift
//  expandableTableViewTasKAPP
//
//  Created by iMac on 16/09/22.
//

import UIKit

class companyInformationCell: UITableViewCell {

    @IBOutlet weak var companyimage: UIImageView!
    @IBOutlet weak var labelCompanyName: UILabel!
    @IBOutlet weak var labelCompanyQuetes: UILabel!
    @IBOutlet weak var labelraisedAmont: UILabel!
    @IBOutlet weak var labelGoalAmount: UILabel!
    @IBOutlet weak var labelPendingInvestment: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setCompanyMainHeading(){
        labelCompanyName.text = tblModel?.data?.value?.formData?.issuerInformation?.issuerInfo?.nameOfIssuer
        if let pendingRaisedAmount = tblModel?.totalPendingInvestment{
            labelPendingInvestment.text = "Pending Raised Amount $\(pendingRaisedAmount)"
        }
        labelCompanyQuetes.text = tblModel?.data?.value?.memo?.offeringTagline
    }
}
