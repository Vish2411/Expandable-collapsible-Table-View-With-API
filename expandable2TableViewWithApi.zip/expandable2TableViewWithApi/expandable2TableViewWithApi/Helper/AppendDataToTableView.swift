//
//  AppendDataToTableView.swift
//  expandable2TableViewWithApi
//
//  Created by iMac on 21/09/22.
//

import Foundation

class companyHeaders{
    var header: String
    var rowData: Int
    var isOpened: Bool
    
    init(header:String = "Hello",rowData:Int, isOpened: Bool = false) {
        self.header = header
        self.rowData = rowData
        self.isOpened = isOpened
    }
}

struct AppendData{
    var offeringData:offeringInformation? = nil
    var holderData:Edgarfilingdocument? = nil
}

// Offering Section Data Get
struct offeringData{
    var key:String
    var value1:String
    var value2:String
}

struct HolderDetails{
    var Name:String
    var image:String
    var provider:String
}
