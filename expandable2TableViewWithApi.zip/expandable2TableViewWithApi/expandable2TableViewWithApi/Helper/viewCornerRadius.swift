//
//  viewCornerRadius.swift
//  expandableTableViewTasKAPP
//
//  Created by iMac on 19/09/22.
//

import Foundation
import UIKit

extension UIView{
    @IBInspectable
      var cornerRadius: CGFloat {
        get {
          return layer.cornerRadius
        }
        set {
          layer.cornerRadius = newValue
        }
      }
}

