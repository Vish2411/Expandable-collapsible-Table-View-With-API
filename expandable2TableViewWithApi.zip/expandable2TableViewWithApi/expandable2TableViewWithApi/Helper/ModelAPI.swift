//
//  Model.swift
//  expandableTableViewApiCall
//
//  Created by iMac on 20/09/22.
//

import Foundation
import UIKit

struct companyData:Codable{
    let status:String?
    let data: data?
    let totalPendingInvestment:Int?
    let edgarfilingdocuments: [Edgarfilingdocument]?
}

// MARK: - Edgarfilingdocument
struct Edgarfilingdocument: Codable {
    let attachment: Attachment?
}

// MARK: - Attachment
struct Attachment: Codable {
    let name: String?
    let url: String?
    let provider: String?
}

struct data:Codable{
    let value: value?
}

struct value:Codable{
    let formData: formData?
    let memo: memo?
}

struct memo:Codable{
    let offeringPurpose:String?
    let productsServices:String?
    let investorPerks:String?
    let businessPlan:String?
    let riskFactors:String?
    let useOfFundsDescription:String?
    let otherMaterial:String?
    let offeringTagline:String?
    
//    enum CodingKeys: String,CodingKey{
//        case companyTagline = "offeringTagline"
//    }
}

struct formData:Codable{
    let issuerInformation:issuerInformation?
    let offeringInformation:offeringInformation?
}

struct issuerInformation:Codable{
    let issuerInfo:issuerInfo?
    let companyName:String?
    let commissionCik:String?
    let commissionFileNumber:String?
    let crdNumber:String?
    let isCoIssuer:String?
}

struct issuerInfo:Codable{
    let legalStatus:legalStatus?
    let nameOfIssuer:String?
    let issuerWebsite:String?
}

struct legalStatus:Codable{
    let legalStatusForm:String?
    let jurisdictionOrganization:String?
    let dateIncorporation:String?
    
}

struct offeringInformation:Codable{
    let noOfSecurityOffered:String?
    let deadlineDate:String?
    let securityOfferedOtherDesc:String?
    let price:String?
    let compensationAmount:String?
    let rollingClose:String?
    let financialInterest:String?
    let securityOfferedType:String?
    let overSubscriptionAccepted:String?
    let priceDeterminationMethod:String?
    let maximumOfferingAmount:String?
    let offeringAmount:String?
}

